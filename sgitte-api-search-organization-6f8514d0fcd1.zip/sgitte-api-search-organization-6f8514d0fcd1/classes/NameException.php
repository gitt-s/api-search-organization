<?php


class NameException extends ValidException
{
    protected $message = "(['status'=>'error', 'msg'=>'name cannot be empty'])";

}