<?php


class CityException extends ValidException
{
    protected $message = "(['status'=>'error', 'msg'=>'city cannot be empty'])";
}