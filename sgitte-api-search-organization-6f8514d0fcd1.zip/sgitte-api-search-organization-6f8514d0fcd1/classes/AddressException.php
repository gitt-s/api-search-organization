<?php


class AddressException extends ValidException
{
    protected $message = "(['status'=>'error', 'msg'=>'address cannot be empty'])";

}