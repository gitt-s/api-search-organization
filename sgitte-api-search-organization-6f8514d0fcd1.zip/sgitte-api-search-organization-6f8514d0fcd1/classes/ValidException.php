<?php


class ValidException extends Exception
{

}