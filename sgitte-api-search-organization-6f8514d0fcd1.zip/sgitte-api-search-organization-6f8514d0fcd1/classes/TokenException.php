<?php


class TokenException extends Exception
{

    protected $message ="Error incorrect token";

}